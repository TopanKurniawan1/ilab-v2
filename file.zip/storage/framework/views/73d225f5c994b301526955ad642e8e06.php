<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Jadwal <?php echo e($class->name); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('css/public-style.css')); ?>">
</head>
<body>
<div class="container">

  
  <div class="header">
    <img src="<?php echo e(asset('images/logo-pplg.png')); ?>" alt="Logo Kiri" class="logo">
    <h1>SMK Negeri 1 Karawang</h1>
    <img src="<?php echo e(asset('images/logo-aws.png')); ?>" alt="Logo Kanan" class="logo">
  </div>

  
  <div class="info-container">
    <div class="info">
      <div class="row">
        <span class="label">NAMA GURU</span>
        <span class="value">
          <?php echo e($jadwalSekarang->teacher->name ?? 'Tidak ada jadwal saat ini'); ?>

        </span>
      </div>

      <div class="row">
        <span class="label">JAM KE</span>
        <span class="value"><?php echo e($jamKe ?? '-'); ?></span>
      </div>

      <div class="row">
        <span class="label">MAPEL</span>
        <span class="value"><?php echo e($jadwalSekarang->subject->name ?? '-'); ?></span>
      </div>

      <div class="row">
        <span class="label">RUANGAN</span>
        <span class="value"><?php echo e($jadwalSekarang->classroom->name ?? '-'); ?></span>
      </div>
    </div>

    <div class="foto">
      <img src="<?php echo e($jadwalSekarang && $jadwalSekarang->teacher->photo ? asset($jadwalSekarang->teacher->photo) : asset('images/default-teacher.png')); ?>" alt="Foto Guru">
    </div>
  </div>

  
  <div class="tanggal">
    <b><?php echo e($hari); ?></b> — <?php echo e(now('Asia/Jakarta')->format('d F Y, H:i')); ?>

  </div>

  
  <?php if(!$jadwalSekarang): ?>
    <div class="text-center" style="margin-top:30px;">
      <h3 style="color:#888;">Tidak ada pelajaran berlangsung saat ini.</h3>
    </div>
  <?php endif; ?>

</div>
</body>
</html>
<?php /**PATH C:\Users\komon\OneDrive\Documents\TUGAS\XII RPL 2\pak-ucup\ilab-v2\resources\views/public_schedules/show.blade.php ENDPATH**/ ?>