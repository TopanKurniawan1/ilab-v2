

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
  <h2 class="mb-3">👩‍🏫 Data Guru</h2>

  
  <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Ukuran foto tidak boleh melebihi 2MB</strong>
      <ul class="mb-0">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  
  <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <?php echo e(session('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  
  <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addTeacherModal">
    + Tambah Guru
  </button>

  
  <table class="table table-bordered align-middle table-striped">
    <thead class="table-dark text-center">
      <tr>
        <th style="width:50px;">#</th>
        <th>Foto</th>
        <th>Nama</th>
        <th>NIP</th>
        <th>Email</th>
        <th>Telepon</th>
        <th>Mata Pelajaran</th>
        <th style="width:150px;">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td class="text-center"><?php echo e($loop->iteration); ?></td>
        <td class="text-center">
          <?php if($teacher->photo): ?>
            <img src="<?php echo e(asset($teacher->photo)); ?>" alt="Foto <?php echo e($teacher->name); ?>"
                 width="60" height="60" class="rounded border" style="object-fit:cover;">
          <?php else: ?>
            <span class="text-muted">-</span>
          <?php endif; ?>
        </td>
        <td><?php echo e($teacher->name); ?></td>
        <td><?php echo e($teacher->nip ?? '-'); ?></td>
        <td><?php echo e($teacher->email ?? '-'); ?></td>
        <td><?php echo e($teacher->phone ?? '-'); ?></td>
        <td><?php echo e($teacher->subject->name ?? '-'); ?></td>
<td class="text-center">
  <div class="d-flex justify-content-center gap-2">
    <!-- Tombol Edit -->
    <button class="btn btn-sm btn-warning px-2 py-1"
            style="font-size: 13px; min-width: 70px;"
            data-bs-toggle="modal"
            data-bs-target="#editTeacherModal<?php echo e($teacher->id); ?>">
      ✏️ Edit
    </button>

    <!-- Tombol Hapus -->
    <form action="<?php echo e(route('teachers.destroy', $teacher->id)); ?>"
          method="POST"
          onsubmit="return confirm('Yakin hapus guru ini?')"
          class="m-0">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button class="btn btn-sm btn-danger px-2 py-1"
              style="font-size: 13px; min-width: 70px;">
        🗑 Hapus
      </button>
    </form>
  </div>
</td>


      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8" class="text-center text-muted">Belum ada data guru.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- ===================== MODAL TAMBAH GURU ===================== -->
<div class="modal fade" id="addTeacherModal" tabindex="-1" aria-labelledby="addTeacherLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="<?php echo e(route('teachers.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title" id="addTeacherLabel">Tambah Guru</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nama</label>
              <input type="text" name="name" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">NIP</label>
              <input type="text" name="nip" class="form-control">
            </div>
            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control">
            </div>
            <div class="col-md-6">
              <label class="form-label">Telepon</label>
              <input type="text" name="phone" class="form-control">
            </div>
            <div class="col-md-6">
              <label class="form-label">Mata Pelajaran</label>
              <select name="subject_id" class="form-select">
                <option value="">-- Pilih Mapel --</option>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Foto Guru</label>
              <input type="file" name="photo" class="form-control" accept="image/*">
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">💾 Simpan</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- ===================== MODAL EDIT GURU ===================== -->
<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editTeacherModal<?php echo e($teacher->id); ?>" tabindex="-1" aria-labelledby="editTeacherLabel<?php echo e($teacher->id); ?>" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="<?php echo e(route('teachers.update', $teacher->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="modal-header bg-warning text-dark">
          <h5 class="modal-title" id="editTeacherLabel<?php echo e($teacher->id); ?>">Edit Guru</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nama</label>
              <input type="text" name="name" class="form-control" value="<?php echo e($teacher->name); ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">NIP</label>
              <input type="text" name="nip" class="form-control" value="<?php echo e($teacher->nip); ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" value="<?php echo e($teacher->email); ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Telepon</label>
              <input type="text" name="phone" class="form-control" value="<?php echo e($teacher->phone); ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Mata Pelajaran</label>
              <select name="subject_id" class="form-select">
                <option value="">-- Pilih Mapel --</option>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($subject->id); ?>" <?php echo e($teacher->subject_id == $subject->id ? 'selected' : ''); ?>>
                    <?php echo e($subject->name); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Foto Guru</label>
              <input type="file" name="photo" class="form-control" accept="image/*">
              <?php if($teacher->photo): ?>
                <div class="mt-2 text-center">
                  <img src="<?php echo e(asset($teacher->photo)); ?>" alt="Foto <?php echo e($teacher->name); ?>"
                       width="80" height="80" class="rounded border" style="object-fit:cover;">
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-warning">💾 Update</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\komon\OneDrive\Documents\TUGAS\XII RPL 2\pak-ucup\ilab-v2\resources\views/teachers/index.blade.php ENDPATH**/ ?>