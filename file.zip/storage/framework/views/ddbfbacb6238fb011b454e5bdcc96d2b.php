

<?php $__env->startSection('title', 'Jadwal Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h2 class="mb-4 text-center">📘 Jadwal Mingguan Semua Kelas</h2>

  <div class="row g-4">
    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <div class="card shadow-sm h-100">
          <div class="card-body text-center">
            <h5 class="card-title mb-1"><?php echo e($c->name); ?></h5>
            <p class="text-muted mb-3"><?php echo e($c->major->name ?? '—'); ?></p>
            <a href="<?php echo e(route('public.schedules.show', $c->id)); ?>" class="btn btn-primary w-100">
              📅 Tampilkan Jadwal
            </a>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\komon\OneDrive\Documents\TUGAS\XII RPL 2\pak-ucup\ilab-v2\resources\views/public_schedules/index.blade.php ENDPATH**/ ?>