<h5>Jadwal Mingguan Kelas <?php echo e($class->name); ?></h5>

<?php $__currentLoopData = ['Senin','Selasa','Rabu','Kamis','Jumat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <h6 class="mt-3"><?php echo e($day); ?></h6>
  <table class="table table-bordered table-sm align-middle">
    <thead>
      <tr>
        <th style="width:60px">Jam</th>
        <th>Mapel</th>
        <th>Guru</th>
        <th>Ruangan</th>
      </tr>
    </thead>
    <tbody>
      <?php
        $daySchedules = $schedules->where('day', $day);
      ?>
      <?php for($p = 1; $p <= 10; $p++): ?>
        <?php
          $s = $daySchedules->firstWhere('period', $p);
        ?>
        <tr>
          <td class="text-center"><?php echo e($p); ?></td>
          <td><?php echo e($s->subject->name ?? '-'); ?></td>
          <td><?php echo e($s->teacher->name ?? '-'); ?></td>
          <td><?php echo e($s->classroom->name ?? '-'); ?></td>
        </tr>
      <?php endfor; ?>
    </tbody>
  </table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\komon\OneDrive\Documents\TUGAS\XII RPL 2\pak-ucup\ilab-v2\resources\views/schedules/partials/view.blade.php ENDPATH**/ ?>