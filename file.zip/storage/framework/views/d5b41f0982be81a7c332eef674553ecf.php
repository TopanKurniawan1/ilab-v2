


<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Daftar Jurusan</h2>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMajorModal">+ Tambah Jurusan</button>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table table-bordered align-middle">
    <thead class="table-light">
        <tr>
            <th style="width: 50px;">#</th>
            <th>Nama Jurusan</th>
            <th>Kode</th>
            <th style="width: 180px;">Aksi</th>
        </tr>
        <link rel="stylesheet" href="<?php echo e(asset('major.css')); ?>">

    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($major->name); ?></td>
            <td><?php echo e($major->code ?? '-'); ?></td>
            <td>
                <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editMajorModal<?php echo e($major->id); ?>">Edit</button>
                <form action="<?php echo e(route('majors.destroy', $major)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus jurusan ini?')">Hapus</button>
                </form>
            </td>
        </tr>

        <!-- Modal Edit -->
        <div class="modal fade" id="editMajorModal<?php echo e($major->id); ?>" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <form action="<?php echo e(route('majors.update', $major)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                  <h5 class="modal-title">Edit Jurusan</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                  <div class="mb-3">
                    <label>Nama Jurusan</label>
                    <input type="text" name="name" value="<?php echo e($major->name); ?>" class="form-control" required>
                  </div>
                  <div class="mb-3">
                    <label>Kode</label>
                    <input type="text" name="code" value="<?php echo e($major->code); ?>" class="form-control">
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                  <button type="submit" class="btn btn-success">Simpan</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="4" class="text-center text-muted">Belum ada data jurusan</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Modal Tambah -->
<div class="modal fade" id="addMajorModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('majors.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-header">
          <h5 class="modal-title">Tambah Jurusan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label>Nama Jurusan</label>
            <input type="text" name="name" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Kode</label>
            <input type="text" name="code" class="form-control">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\komon\OneDrive\Documents\TUGAS\XII RPL 2\pak-ucup\ilab-v2\resources\views/majors/index.blade.php ENDPATH**/ ?>