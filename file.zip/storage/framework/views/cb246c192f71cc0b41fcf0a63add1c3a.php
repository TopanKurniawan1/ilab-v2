<div class="mb-3">
  <label>Hari</label>
  <select name="day" class="form-select" required>
    <?php $__currentLoopData = ['Senin','Selasa','Rabu','Kamis','Jumat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($day); ?>" <?php echo e((isset($schedule) && $schedule->day == $day) ? 'selected' : ''); ?>><?php echo e($day); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>

<div class="mb-3">
  <label>Jam ke</label>
  <input type="number" name="period" class="form-control" value="<?php echo e($schedule->period ?? ''); ?>" min="1" max="10" required>
</div>

<div class="mb-3">
  <label>Kelas</label>
  <select name="class_id" class="form-select" required>
    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($c->id); ?>" <?php echo e((isset($schedule) && $schedule->class_id == $c->id) ? 'selected' : ''); ?>>
        <?php echo e($c->name); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>

<div class="mb-3">
  <label>Mata Pelajaran</label>
  <select name="subject_id" class="form-select">
    <option value="">— Pilih Mapel —</option>
    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($sub->id); ?>" <?php echo e((isset($schedule) && $schedule->subject_id == $sub->id) ? 'selected' : ''); ?>>
        <?php echo e($sub->name); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>

<div class="mb-3">
  <label>Guru</label>
  <select name="teacher_id" class="form-select">
    <option value="">— Pilih Guru —</option>
    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($t->id); ?>" <?php echo e((isset($schedule) && $schedule->teacher_id == $t->id) ? 'selected' : ''); ?>>
        <?php echo e($t->name); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>

<div class="mb-3">
  <label>Ruangan</label>
  <select name="classroom_id" class="form-select">
    <option value="">— Pilih Ruangan —</option>
    <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($r->id); ?>" <?php echo e((isset($schedule) && $schedule->classroom_id == $r->id) ? 'selected' : ''); ?>>
        <?php echo e($r->name); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>
<?php /**PATH C:\Users\komon\OneDrive\Documents\TUGAS\XII RPL 2\pak-ucup\ilab-v2\resources\views/schedules/partials/form.blade.php ENDPATH**/ ?>